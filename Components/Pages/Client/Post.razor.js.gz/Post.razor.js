﻿export class Post {
  
}

window.Post = Post;